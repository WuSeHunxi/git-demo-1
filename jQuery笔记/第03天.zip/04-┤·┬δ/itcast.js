/**
 * Created by HUCC on 2017/4/11.
 */
var $ = {
  name:"zs",
  age:18
};