/**
 * Created by Administrator on 2017-10-07.
 */
function my$(id) {
    return document.getElementById(id);
}